package com.pfa.cameraupload;

import java.util.ArrayList;
import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface JsonPlaceHolderApi {
    @GET("webapi/enseignant/Seances/All")
    Call<ArrayList<Seance>> getSeancesAll(@Header("Authorization") String authKey);
    @GET("webapi/enseignant/Seances/")
    Call<ArrayList<Seance>> getSeances(@Header("Authorization") String authKey);
    @GET("webapi/enseignant/Seances/{idSeance}/Etudiants")
    Call<ArrayList<SeanceEtuds>> getEtudiantsAll(@Path("idSeance") Long idSeance);
    @GET("webapi/enseignant/Seances/{idSeance}/Absence")
    Call<ArrayList<SeanceEtuds>> getEtudiantsAbs(@Path("idSeance") Long idSeance);
    @POST("webapi/enseignant/Seances/Absence/Add")
    Call<SeanceAbsence> AddAbsence(@Body SeanceAbsence seanceAbsence);
    @POST("webapi/enseignant/Seances/Absence/Remove")
    Call<SeanceAbsence> RemoveAbsence(@Body SeanceAbsence seanceAbsence);
    @Multipart
    @POST("webapi/enseignant/upload")
    Call<ArrayList<SeanceEtudsFac>> upload(@Part MultipartBody.Part file,@Part("idSeance") RequestBody idSeance);
}
